/**
 * Matrix-themed utility functions for visual effects
 */

// Generate random Matrix character
export const getRandomMatrixChar = (): string => {
  const chars = "01";
  return chars.charAt(Math.floor(Math.random() * chars.length));
};

// Generate a string of random matrix characters
export const generateMatrixString = (length: number): string => {
  let result = '';
  for (let i = 0; i < length; i++) {
    result += getRandomMatrixChar();
  }
  return result;
};

// Generate a Matrix-style random ID
export const generateMatrixId = (length: number = 8): string => {
  return generateMatrixString(length);
};

// Generate a random payment amount between min and max
export const generateRandomPayment = (min: number = 0.10, max: number = 0.58): number => {
  return parseFloat((Math.random() * (max - min) + min).toFixed(2));
};

// Calculate progress percentage
export const calculateProgress = (current: number, goal: number): number => {
  return Math.min(100, Math.round((current / goal) * 100));
};

// Create a typing effect animation
interface TypingEffect {
  text: string;
  speed: number;
  onComplete?: () => void;
}

export const startTypingEffect = ({ text, speed, onComplete }: TypingEffect): {
  stop: () => void;
} => {
  let index = 0;
  const element = document.getElementById('matrix-typing');
  
  if (!element) {
    console.error('Element with id "matrix-typing" not found');
    return { stop: () => {} };
  }
  
  element.textContent = '';
  
  const typingInterval = setInterval(() => {
    if (index < text.length) {
      element.textContent += text.charAt(index);
      index++;
    } else {
      clearInterval(typingInterval);
      if (onComplete) onComplete();
    }
  }, speed);
  
  return {
    stop: () => clearInterval(typingInterval)
  };
};

// Matrix fade-in animation settings
export const matrixFadeIn = {
  initial: { opacity: 0 },
  animate: { opacity: 1 },
  transition: { duration: 0.5 }
};

// Matrix slide-in animation settings
export const matrixSlideIn = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 }
};

// Get color for different categories
export const getCategoryColor = (category: string): string => {
  switch (category) {
    case "book-promotion":
      return "bg-pill-red";
    case "digital-marketing":
      return "bg-pill-blue";
    case "video-creation":
      return "bg-green-600";
    case "payment-concept":
      return "bg-yellow-600";
    default:
      return "bg-gray-600";
  }
};

// Get status text and color
export const getStatusStyles = (status: string): { 
  color: string;
  text: string;
  icon: string;
  statusColor: string;
  statusBg: string;
} => {
  switch (status) {
    case "approved":
      return {
        color: "text-matrix-green",
        text: "Approved",
        icon: "fa-check-circle",
        statusColor: "text-matrix-green",
        statusBg: "bg-matrix-green/20"
      };
    case "pending":
      return {
        color: "text-yellow-500",
        text: "Pending",
        icon: "fa-clock",
        statusColor: "text-yellow-500",
        statusBg: "bg-yellow-500/20"
      };
    case "rejected":
      return {
        color: "text-red-500",
        text: "Rejected",
        icon: "fa-times-circle",
        statusColor: "text-red-500",
        statusBg: "bg-red-500/20"
      };
    default:
      return {
        color: "text-gray-400",
        text: status,
        icon: "fa-question-circle",
        statusColor: "text-gray-400",
        statusBg: "bg-gray-400/20"
      };
  }
};

// Format date relative to current time
export const formatRelativeTime = (dateStr: Date): string => {
  const date = new Date(dateStr);
  const now = new Date();
  const diffSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
  
  if (diffSeconds < 60) {
    return 'just now';
  } else if (diffSeconds < 3600) {
    const minutes = Math.floor(diffSeconds / 60);
    return `${minutes} ${minutes === 1 ? 'minute' : 'minutes'} ago`;
  } else if (diffSeconds < 86400) {
    const hours = Math.floor(diffSeconds / 3600);
    return `${hours} ${hours === 1 ? 'hour' : 'hours'} ago`;
  } else {
    const days = Math.floor(diffSeconds / 86400);
    return `${days} ${days === 1 ? 'day' : 'days'} ago`;
  }
};
