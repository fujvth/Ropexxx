import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Videos from "@/pages/Videos";
import Books from "@/pages/Books";
import Support from "@/pages/Support";
import Auth from "@/pages/Auth";
import AdminDashboard from "@/pages/AdminDashboard";
import ManipulationPage from "@/pages/ManipulationPage";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { useEffect, useState } from "react";
import { apiRequest } from "./lib/queryClient";

function Router() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // Check if user is logged in
    const checkAuth = async () => {
      try {
        const res = await fetch("/api/auth/me", {
          credentials: "include"
        });
        if (res.ok) {
          const userData = await res.json();
          setUser(userData);
        }
      } catch (error) {
        console.error("Error checking auth:", error);
      } finally {
        setLoading(false);
      }
    };
    
    checkAuth();
  }, []);
  
  const handleLogin = (userData: any) => {
    setUser(userData);
  };
  
  const handleLogout = async () => {
    try {
      const response = await fetch("/api/auth/logout", {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json"
        }
      });
      
      if (response.ok) {
        setUser(null);
      } else {
        console.error("Logout failed:", await response.text());
      }
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };
  
  if (loading) {
    return <div className="min-h-screen bg-matrix-black flex items-center justify-center">
      <div className="text-matrix-green text-xl">Loading...</div>
    </div>;
  }
  
  return (
    <div className="bg-matrix-black text-white font-mono min-h-screen flex flex-col">
      <Header user={user} onLogout={handleLogout} />
      <main className="flex-1">
        <Switch>
          {!user ? (
            <>
              <Route path="/">
                <Auth onLogin={handleLogin} />
              </Route>
              <Route path="/auth">
                <Auth onLogin={handleLogin} />
              </Route>
            </>
          ) : (
            <>
              <Route path="/" component={Dashboard} />
              <Route path="/videos" component={Videos} />
              <Route path="/books" component={Books} />
              <Route path="/support" component={Support} />
              <Route path="/manipulation" component={ManipulationPage} />
              {user.isAdmin && <Route path="/admin" component={AdminDashboard} />}
            </>
          )}
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
