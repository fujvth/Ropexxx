import { useState } from "react";
import { Link, useLocation } from "wouter";
import Pill from "@/components/animation/Pill";
import { useQuery } from "@tanstack/react-query";
import ProfileMenu from "./ProfileMenu";

interface HeaderProps {
  user: any;
  onLogout: () => void;
}

const Header = ({ user, onLogout }: HeaderProps) => {
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [location] = useLocation();
  
  const { data: balanceData } = useQuery<{balance: number}>({
    queryKey: ["/api/users/me/balance"],
    enabled: !!user,
  });

  return (
    <header className="border-b border-matrix-green/30 backdrop-blur-sm bg-matrix-black/80 sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Pill />
            <h1 className="text-2xl font-rajdhani font-bold text-matrix-green animate-glow ml-2">ROPEX</h1>
          </div>
          
          {user && (
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/">
                <a className={`${location === '/' ? 'text-white' : 'text-matrix-green'} hover:text-white transition duration-300`}>
                  Dashboard
                </a>
              </Link>
              <Link href="/videos">
                <a className={`${location === '/videos' ? 'text-white' : 'text-matrix-green'} hover:text-white transition duration-300`}>
                  Videos
                </a>
              </Link>
              <Link href="/books">
                <a className={`${location === '/books' ? 'text-white' : 'text-matrix-green'} hover:text-white transition duration-300`}>
                  Books
                </a>
              </Link>
              <Link href="/support">
                <a className={`${location === '/support' ? 'text-white' : 'text-matrix-green'} hover:text-white transition duration-300`}>
                  Support
                </a>
              </Link>
              {user.isAdmin && (
                <Link href="/admin">
                  <a className={`${location === '/admin' ? 'text-white' : 'text-matrix-green'} hover:text-white transition duration-300`}>
                    Admin
                  </a>
                </Link>
              )}
            </nav>
          )}
          
          <div className="flex items-center space-x-4">
            {user && (
              <>
                <span className="hidden md:inline-flex items-center px-3 py-1 rounded-full bg-matrix-gray border border-matrix-green/50">
                  <span className="h-2 w-2 rounded-full bg-matrix-green animate-pulse mr-2"></span>
                  <span className="text-sm text-matrix-green">
                    ${balanceData?.balance?.toFixed(2) || '0.00'}
                  </span>
                </span>
                
                <ProfileMenu user={user} onLogout={onLogout} />
              </>
            )}
            
            <button 
              className="md:hidden text-matrix-green" 
              onClick={() => setShowMobileMenu(!showMobileMenu)}
            >
              <i className="fas fa-bars"></i>
            </button>
          </div>
        </div>
        
        {/* Mobile menu */}
        {user && showMobileMenu && (
          <div className="md:hidden mt-4 pb-4">
            <nav className="flex flex-col space-y-2">
              <Link href="/">
                <a className="text-matrix-green hover:text-white transition duration-300 py-2 border-b border-matrix-green/20">
                  Dashboard
                </a>
              </Link>
              <Link href="/videos">
                <a className="text-matrix-green hover:text-white transition duration-300 py-2 border-b border-matrix-green/20">
                  Videos
                </a>
              </Link>
              <Link href="/books">
                <a className="text-matrix-green hover:text-white transition duration-300 py-2 border-b border-matrix-green/20">
                  Books
                </a>
              </Link>
              <Link href="/support">
                <a className="text-matrix-green hover:text-white transition duration-300 py-2">
                  Support
                </a>
              </Link>
              {user.isAdmin && (
                <Link href="/admin">
                  <a className="text-matrix-green hover:text-white transition duration-300 py-2 border-t border-matrix-green/20">
                    Admin
                  </a>
                </Link>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
