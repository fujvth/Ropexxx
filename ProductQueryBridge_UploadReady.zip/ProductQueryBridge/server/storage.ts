import { 
  users, 
  videos, 
  books, 
  supportTickets, 
  notifications,
  type User, 
  type InsertUser, 
  type Video, 
  type InsertVideo, 
  type Book, 
  type InsertBook, 
  type SupportTicket, 
  type InsertSupportTicket, 
  type Notification, 
  type InsertNotification
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBalance(id: number, balance: number): Promise<User | undefined>;
  
  // Video operations
  getVideo(id: number): Promise<Video | undefined>;
  getUserVideos(userId: number): Promise<Video[]>;
  getAllVideos(): Promise<Video[]>;
  createVideo(video: InsertVideo, userId: number): Promise<Video>;
  updateVideoStatus(id: number, status: string): Promise<Video | undefined>;
  updateVideoViews(id: number, views: number): Promise<Video | undefined>;
  
  // Book operations
  getBook(id: number): Promise<Book | undefined>;
  getAllBooks(): Promise<Book[]>;
  createBook(book: InsertBook): Promise<Book>;
  
  // Support ticket operations
  getSupportTicket(id: number): Promise<SupportTicket | undefined>;
  getUserSupportTickets(userId: number): Promise<SupportTicket[]>;
  getAllSupportTickets(): Promise<SupportTicket[]>;
  createSupportTicket(ticket: InsertSupportTicket, userId: number): Promise<SupportTicket>;
  updateSupportTicketStatus(id: number, status: string): Promise<SupportTicket | undefined>;
  
  // Notification operations
  getNotification(id: number): Promise<Notification | undefined>;
  getUserNotifications(userId: number): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<Notification | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private videos: Map<number, Video>;
  private books: Map<number, Book>;
  private supportTickets: Map<number, SupportTicket>;
  private notifications: Map<number, Notification>;
  
  private currentUserId: number = 1;
  private currentVideoId: number = 1;
  private currentBookId: number = 1;
  private currentTicketId: number = 1;
  private currentNotificationId: number = 1;

  constructor() {
    this.users = new Map();
    this.videos = new Map();
    this.books = new Map();
    this.supportTickets = new Map();
    this.notifications = new Map();
    
    // Initialize with a default admin user
    this.users.set(1, {
      id: 1,
      username: "admin",
      password: "adminpassword", // In a real app, this would be hashed
      name: "Admin User",
      email: "admin@dataoracle.com",
      balance: 0,
      isAdmin: true,
      joinDate: new Date(),
    });
    
    // Add a test user
    this.users.set(2, {
      id: 2,
      username: "test",
      password: "test123", // In a real app, this would be hashed
      name: "Test User",
      email: "test@dataoracle.com",
      balance: 10.45,
      isAdmin: false,
      joinDate: new Date(),
    });
    
    this.currentUserId = 3;
    
    // Initialize with sample books
    this.books.set(1, {
      id: 1,
      title: "Master The Art of Digital Marketing",
      description: "The ultimate guide to exceptional results in the digital landscape. Our bestselling reference for product managers and marketing professionals.",
      coverImage: "https://images.unsplash.com/photo-1531297484001-80022131f5a1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
      features: ["Over 58 proven marketing techniques", "Exclusive digital marketing strategies", "Actionable promotional frameworks"],
      author: "Sarah Johnson",
      buyLink: "",
      createdAt: new Date(),
    });
    
    // Add a second book with "MASTER MANIPULATION" theme
    this.books.set(2, {
      id: 2,
      title: "MASTER MANIPULATION: The Persuasion Blueprint",
      description: "BE UNBELIEVABLE. Learn the secret techniques of influence and persuasion to control any situation and achieve your goals. This groundbreaking book reveals over 58 proven techniques to master the art of psychological manipulation.",
      coverImage: "/master_manipulation_cover.png",
      features: [
        "58+ proven techniques for advanced influence",
        "Psychological manipulation frameworks",
        "Negotiation mastery system",
        "Covert persuasion tactics",
        "Mind control techniques",
        "Body language manipulation",
        "Verbal command strategies",
        "Practical real-world applications"
      ],
      author: "Dr. Marcus Reed, Ph.D in Behavioral Psychology",
      buyLink: "https://books2read.com/u/499gKd",
      createdAt: new Date(),
    });
    
    this.currentBookId = 3;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      balance: 0, 
      isAdmin: false,
      joinDate: new Date() 
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserBalance(id: number, balance: number): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, balance };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Video operations
  async getVideo(id: number): Promise<Video | undefined> {
    return this.videos.get(id);
  }
  
  async getUserVideos(userId: number): Promise<Video[]> {
    return Array.from(this.videos.values()).filter(
      (video) => video.userId === userId
    );
  }
  
  async getAllVideos(): Promise<Video[]> {
    return Array.from(this.videos.values());
  }
  
  async createVideo(insertVideo: InsertVideo, userId: number): Promise<Video> {
    const id = this.currentVideoId++;
    
    // Generate random payment between $0.10 and $0.58
    const payment = parseFloat((Math.random() * (0.58 - 0.10) + 0.10).toFixed(2));
    
    const video: Video = {
      ...insertVideo,
      id,
      userId,
      bookId: insertVideo.bookId,
      payment,
      status: "pending",
      views: 0,
      createdAt: new Date()
    };
    
    this.videos.set(id, video);
    return video;
  }
  
  async updateVideoStatus(id: number, status: string): Promise<Video | undefined> {
    const video = this.videos.get(id);
    if (!video) return undefined;
    
    const updatedVideo = { ...video, status };
    this.videos.set(id, updatedVideo);
    
    // If video is approved AND it's for the MASTER MANIPULATION book (id=2), update user balance
    if (status === "approved" && video.payment && video.bookId === 2) {
      const user = this.users.get(video.userId);
      if (user) {
        const newBalance = user.balance + video.payment;
        await this.updateUserBalance(user.id, newBalance);
        
        // Create notification about successful payment
        await this.createNotification({
          title: "Payment Received",
          message: `You've earned $${video.payment.toFixed(2)} for your MASTER MANIPULATION book promotion!`,
          type: "payment",
          userId: user.id
        });
        
        // Check if user reached $20 threshold
        if (user.balance < 20 && newBalance >= 20) {
          await this.createNotification({
            title: "Payment Threshold Reached",
            message: "Congratulations! You've reached the $20 payment threshold. Your payment will be processed within 5-7 business days.",
            type: "achievement",
            userId: user.id
          });
        }
      }
    } else if (status === "approved" && video.bookId !== 2) {
      // Create notification that this video doesn't qualify for payment
      const user = this.users.get(video.userId);
      if (user) {
        await this.createNotification({
          title: "No Payment for This Video",
          message: "Your video was approved but no payment was added as it does not promote the MASTER MANIPULATION book. Only videos promoting MASTER MANIPULATION qualify for payment.",
          type: "payment",
          userId: user.id
        });
      }
    }
    
    return updatedVideo;
  }
  
  async updateVideoViews(id: number, views: number): Promise<Video | undefined> {
    const video = this.videos.get(id);
    if (!video) return undefined;
    
    const updatedVideo = { ...video, views };
    this.videos.set(id, updatedVideo);
    return updatedVideo;
  }
  
  async updateVideoPayment(id: number, payment: number): Promise<Video | undefined> {
    const video = this.videos.get(id);
    if (!video) return undefined;
    
    const updatedVideo = { ...video, payment };
    this.videos.set(id, updatedVideo);
    return updatedVideo;
  }
  
  // Book operations
  async getBook(id: number): Promise<Book | undefined> {
    return this.books.get(id);
  }
  
  async getAllBooks(): Promise<Book[]> {
    return Array.from(this.books.values());
  }
  
  async createBook(book: InsertBook): Promise<Book> {
    const id = this.currentBookId++;
    const newBook: Book = {
      ...book,
      id,
      author: book.author || null,
      buyLink: book.buyLink || "",
      createdAt: new Date()
    };
    
    this.books.set(id, newBook);
    return newBook;
  }
  
  // Support ticket operations
  async getSupportTicket(id: number): Promise<SupportTicket | undefined> {
    return this.supportTickets.get(id);
  }
  
  async getUserSupportTickets(userId: number): Promise<SupportTicket[]> {
    return Array.from(this.supportTickets.values()).filter(
      (ticket) => ticket.userId === userId
    );
  }
  
  async getAllSupportTickets(): Promise<SupportTicket[]> {
    return Array.from(this.supportTickets.values());
  }
  
  async createSupportTicket(insertTicket: InsertSupportTicket, userId: number): Promise<SupportTicket> {
    const id = this.currentTicketId++;
    const ticket: SupportTicket = {
      ...insertTicket,
      id,
      userId,
      status: "open",
      createdAt: new Date()
    };
    
    this.supportTickets.set(id, ticket);
    return ticket;
  }
  
  async updateSupportTicketStatus(id: number, status: string): Promise<SupportTicket | undefined> {
    const ticket = this.supportTickets.get(id);
    if (!ticket) return undefined;
    
    const updatedTicket = { ...ticket, status };
    this.supportTickets.set(id, updatedTicket);
    return updatedTicket;
  }
  
  // Notification operations
  async getNotification(id: number): Promise<Notification | undefined> {
    return this.notifications.get(id);
  }
  
  async getUserNotifications(userId: number): Promise<Notification[]> {
    return Array.from(this.notifications.values()).filter(
      (notification) => notification.userId === userId
    );
  }
  
  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const id = this.currentNotificationId++;
    const notification: Notification = {
      id,
      userId: insertNotification.userId,
      title: insertNotification.title,
      message: insertNotification.message,
      type: insertNotification.type || "general",
      read: false,
      createdAt: new Date()
    };
    
    this.notifications.set(id, notification);
    return notification;
  }
  
  async markNotificationAsRead(id: number): Promise<Notification | undefined> {
    const notification = this.notifications.get(id);
    if (!notification) return undefined;
    
    const updatedNotification = { ...notification, read: true };
    this.notifications.set(id, updatedNotification);
    return updatedNotification;
  }
}

export const storage = new MemStorage();
