import { useState } from 'react';
import { motion } from 'framer-motion';
import { Video } from '@shared/schema';
import { getStatusStyles, formatRelativeTime } from '@/lib/matrix-utils';
import { Badge } from '@/components/ui/badge';

interface VideoCardProps {
  video: Video;
}

const VideoCard = ({ video }: VideoCardProps) => {
  const [isHovered, setIsHovered] = useState(false);
  
  const { statusColor, statusBg } = getStatusStyles(video.status);
  
  // Helper function to extract video ID from common video platform URLs
  const getVideoThumbnail = (url: string) => {
    try {
      // YouTube
      if (url.includes('youtube.com') || url.includes('youtu.be')) {
        const videoId = url.includes('v=') 
          ? url.split('v=')[1].split('&')[0]
          : url.split('/').pop()?.split('?')[0];
        return `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`;
      }
      
      // If not a recognized platform, return a default thumbnail
      return 'https://placehold.co/640x360/1a1a1a/00FF00?text=Video+Thumbnail';
    } catch (error) {
      return 'https://placehold.co/640x360/1a1a1a/00FF00?text=Video+Thumbnail';
    }
  };
  
  const thumbnailUrl = getVideoThumbnail(video.link);
  
  return (
    <motion.div 
      className={`bg-matrix-black border ${video.bookId === 2 ? 'border-matrix-green' : 'border-matrix-green/30'} rounded-lg overflow-hidden shadow-lg`}
      whileHover={{ 
        scale: 1.02,
        boxShadow: video.bookId === 2 ? '0 0 15px rgba(0, 255, 0, 0.3)' : 'none'
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="relative">
        <div className="aspect-video bg-gray-800 overflow-hidden">
          <img 
            src={thumbnailUrl} 
            alt={video.title} 
            className="w-full h-full object-cover transition-transform duration-500"
            style={{ transform: isHovered ? 'scale(1.05)' : 'scale(1.0)' }}
          />
        </div>
        
        <div className="absolute top-2 right-2 flex gap-2">
          {video.bookId === 2 && (
            <Badge className="bg-matrix-green/20 text-matrix-green border border-matrix-green">
              PAID
            </Badge>
          )}
          <Badge
            className={`${statusBg} ${statusColor} border border-${statusColor}`}
          >
            {video.status.charAt(0).toUpperCase() + video.status.slice(1)}
          </Badge>
        </div>
        
        {video.payment && (
          <div className="absolute bottom-2 right-2 bg-black/70 px-2 py-1 rounded text-xs text-matrix-green font-mono">
            +${video.payment.toFixed(2)}
          </div>
        )}
        
        {/* Book label */}
        <div className="absolute bottom-2 left-2">
          <Badge
            className={`${video.bookId === 2 
              ? 'bg-matrix-green/20 text-matrix-green border border-matrix-green' 
              : 'bg-gray-800/90 text-gray-300 border border-gray-600'}`}
          >
            {video.bookId === 2 ? 'MASTER MANIPULATION' : 'DIGITAL MARKETING'}
          </Badge>
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="text-lg font-bold text-white mb-2 line-clamp-1">{video.title}</h3>
        <p className="text-gray-400 text-sm mb-3 line-clamp-2">{video.description}</p>
        
        <div className="flex justify-between items-center text-xs text-gray-500">
          <div className="flex items-center">
            <i className="fas fa-calendar-alt mr-1"></i>
            <span>{formatRelativeTime(video.createdAt)}</span>
          </div>
          
          <div className="flex items-center">
            <i className="fas fa-eye mr-1"></i>
            <span>{video.views} views</span>
          </div>
        </div>
      </div>
      
      <div className="p-3 bg-matrix-black border-t border-matrix-green/20">
        <a 
          href={video.link} 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-matrix-green hover:text-matrix-green/80 text-sm flex items-center justify-center transition-colors"
        >
          <i className="fas fa-external-link-alt mr-2"></i>
          View Video
        </a>
      </div>
    </motion.div>
  );
};

export default VideoCard;