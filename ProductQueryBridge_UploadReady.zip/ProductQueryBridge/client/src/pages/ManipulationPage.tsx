import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { matrixFadeIn, matrixSlideIn } from '@/lib/matrix-utils';
import Pill from '@/components/animation/Pill';
import MatrixRain from '@/components/animation/MatrixRain';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'wouter';

const ManipulationPage = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [pillVisible, setPillVisible] = useState(false);
  
  // Get the book data
  const { data: book } = useQuery({
    queryKey: ['/api/books/2'],
    queryFn: async () => {
      const res = await fetch('/api/books/2');
      if (!res.ok) throw new Error('Failed to fetch book');
      return res.json();
    },
  });
  
  useEffect(() => {
    // Delay showing the pill for visual effect
    const timer = setTimeout(() => {
      setPillVisible(true);
    }, 1500);
    
    return () => clearTimeout(timer);
  }, []);
  
  // Visual content based on the attached assets and described themes
  return (
    <div className="min-h-screen bg-matrix-black">
      {/* Matrix Rain Effect */}
      <div className="fixed inset-0 z-0 opacity-40">
        <MatrixRain />
      </div>
      
      <div className="relative z-10 container mx-auto px-4 pt-16 pb-24">
        {/* Hero Section */}
        <div className="flex flex-col lg:flex-row items-center mb-20">
          <motion.div 
            className="lg:w-1/2 mb-8 lg:mb-0"
            initial="hidden"
            animate="visible"
            variants={matrixFadeIn}
          >
            <motion.div
              className="relative mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.8 }}
            >
              <img 
                src="/be_unbelievable_pill.jpg" 
                alt="BE UNBELIEVABLE - CHOICE IS YOURS" 
                className="w-full max-w-md shadow-[0_0_30px_rgba(0,255,0,0.3)] rounded-lg"
              />
            </motion.div>
            
            <motion.p 
              className="text-xl lg:text-2xl mb-8 text-gray-400"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.8 }}
            >
              Master the art of manipulation and persuasion. Learn the secret techniques 
              that will transform how you influence others.
            </motion.p>
            
            <div className="flex flex-wrap gap-4">
              <a 
                href="https://books2read.com/u/499gKd" 
                target="_blank" 
                rel="noopener noreferrer"
              >
                <Button 
                  className="bg-matrix-green hover:bg-matrix-green/80 text-black font-bold text-lg"
                  size="lg"
                >
                  Order Now
                </Button>
              </a>
              
              <Link href="/videos">
                <Button 
                  className="bg-transparent border-2 border-matrix-green hover:bg-matrix-green/20 text-matrix-green font-bold text-lg"
                  size="lg"
                >
                  Promote This Book
                </Button>
              </Link>
            </div>
          </motion.div>
          
          <motion.div 
            className="lg:w-1/2 flex justify-center relative"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6, duration: 1 }}
          >
            {/* Floating book and pill effect */}
            {book && (
              <motion.div
                className="relative"
                animate={{ 
                  y: [0, -15, 0],
                }}
                transition={{ 
                  duration: 4,
                  repeat: Infinity,
                  repeatType: "reverse"
                }}
              >
                <img 
                  src={book.coverImage} 
                  alt={book.title} 
                  className="rounded-md w-64 lg:w-80 shadow-[0_0_30px_rgba(0,255,0,0.3)]"
                />
                
                {/* Floating descriptive words */}
                <motion.div 
                  className="absolute -top-10 -right-20 bg-matrix-green/20 border border-matrix-green px-4 py-2 rounded-full text-matrix-green font-bold"
                  animate={{ 
                    rotate: [0, 5, 0, -5, 0],
                  }}
                  transition={{ 
                    duration: 8,
                    repeat: Infinity
                  }}
                >
                  Persuasion
                </motion.div>
                
                <motion.div 
                  className="absolute -bottom-8 -left-10 bg-matrix-green/20 border border-matrix-green px-4 py-2 rounded-full text-matrix-green font-bold"
                  animate={{ 
                    rotate: [0, -5, 0, 5, 0],
                  }}
                  transition={{ 
                    duration: 8,
                    repeat: Infinity
                  }}
                >
                  Control
                </motion.div>
                
                {/* Red/Blue pill effect */}
                {pillVisible && (
                  <div className="absolute -right-20 top-1/2 transform -translate-y-1/2">
                    <Pill color="red" onClick={() => {
                      toast({
                        title: "You chose the red pill",
                        description: "Welcome to the path of manipulation mastery.",
                      });
                    }} />
                  </div>
                )}
              </motion.div>
            )}
          </motion.div>
        </div>
        
        {/* Feature Section */}
        {book && (
          <motion.div 
            className="mb-20"
            initial="hidden"
            animate="visible"
            variants={matrixSlideIn}
          >
            <h2 className="text-4xl font-bold text-white mb-12 text-center">
              <span className="text-matrix-green">MASTER</span> MANIPULATION
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {book.features?.map((feature: string, index: number) => (
                <motion.div 
                  key={index} 
                  className="bg-matrix-black border border-matrix-green/30 rounded-lg p-6 transform transition-all duration-300 hover:border-matrix-green hover:shadow-[0_0_20px_rgba(0,255,0,0.15)]"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * index, duration: 0.5 }}
                >
                  <div className="text-matrix-green text-3xl mb-4">0{index + 1}</div>
                  <h3 className="text-white text-xl mb-2">{feature}</h3>
                  <p className="text-gray-400">Unlock the secrets of influence and persuasion with proven psychological techniques.</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
        
        {/* CTA Section */}
        <motion.div 
          className="bg-matrix-black border border-matrix-green/50 rounded-lg p-10 text-center"
          initial="hidden"
          animate="visible"
          variants={matrixFadeIn}
        >
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            Ready to <span className="text-matrix-green">Master Manipulation</span>?
          </h2>
          <p className="text-gray-400 text-lg mb-8 max-w-2xl mx-auto">
            Join thousands who have already unlocked the power of persuasion. 
            Learn the techniques that will change how you negotiate, influence, and succeed.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4">
            <a 
              href="https://books2read.com/u/499gKd" 
              target="_blank" 
              rel="noopener noreferrer"
            >
              <Button 
                className="bg-matrix-green hover:bg-matrix-green/80 text-black font-bold text-lg"
                size="lg"
              >
                Get The Book
              </Button>
            </a>
            
            <Link href="/videos">
              <Button 
                className="bg-transparent border-2 border-matrix-green hover:bg-matrix-green/20 text-matrix-green font-bold text-lg"
                size="lg"
              >
                Earn By Promoting
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default ManipulationPage;