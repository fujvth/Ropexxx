import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqItems = [
  {
    question: "How are video payments calculated?",
    answer: "Payments range from $0.10 to $0.58 per approved video. The exact amount is randomly generated based on our algorithm that considers quality, engagement potential, and relevance."
  },
  {
    question: "When do I receive payment?",
    answer: "Payments are processed once you reach the $20 threshold. You'll receive a congratulatory notification and payment will be sent to your registered payment method within 5-7 business days."
  },
  {
    question: "What type of videos are accepted?",
    answer: "We accept videos related to book promotion, digital marketing, video creation, and payment concepts. All content must be original, follow our community guidelines, and be appropriate for professional audiences."
  },
  {
    question: "How long does video approval take?",
    answer: "Video approval typically takes 24-48 hours. Once approved, payment will be credited to your account balance immediately."
  }
];

const FaqSection = () => {
  return (
    <div className="bg-matrix-gray border border-matrix-green/30 rounded-lg p-6 hover:border-matrix-green/60 transition-all duration-300">
      <h3 className="font-rajdhani text-xl font-bold text-matrix-green mb-4">Frequently Asked Questions</h3>
      
      <Accordion type="single" collapsible className="space-y-4">
        {faqItems.map((item, index) => (
          <AccordionItem 
            key={index} 
            value={`faq-${index}`}
            className="border-b border-matrix-green/20 pb-3"
          >
            <AccordionTrigger className="font-medium text-white hover:text-matrix-green flex justify-between">
              {item.question}
            </AccordionTrigger>
            <AccordionContent className="mt-2 text-sm text-gray-400">
              {item.answer}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
};

export default FaqSection;
