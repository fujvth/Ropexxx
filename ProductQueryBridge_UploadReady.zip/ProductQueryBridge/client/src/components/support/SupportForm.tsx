import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertSupportTicketSchema } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const SupportForm = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const form = useForm({
    resolver: zodResolver(insertSupportTicketSchema),
    defaultValues: {
      subject: "",
      category: "",
      description: "",
    },
  });
  
  const mutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/support-tickets", data),
    onSuccess: async () => {
      queryClient.invalidateQueries({ queryKey: ["/api/support-tickets"] });
      toast({
        title: "Support ticket submitted",
        description: "We'll get back to you soon.",
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Failed to submit ticket",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: any) => {
    mutation.mutate(data);
  };
  
  return (
    <div className="bg-matrix-gray border border-matrix-green/30 rounded-lg p-6 hover:border-matrix-green/60 transition-all duration-300">
      <h3 className="font-rajdhani text-xl font-bold text-matrix-green mb-4">Create Support Ticket</h3>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="subject"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-gray-400">Subject</FormLabel>
                <FormControl>
                  <Input 
                    {...field} 
                    placeholder="Brief description of your issue" 
                    className="bg-matrix-black border-matrix-green/30 focus:border-matrix-green focus:ring-matrix-green/50"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="category"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-gray-400">Category</FormLabel>
                <Select 
                  onValueChange={field.onChange} 
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger className="bg-matrix-black border-matrix-green/30 focus:border-matrix-green focus:ring-matrix-green/50">
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent className="bg-matrix-gray border-matrix-green/30">
                    <SelectItem value="payment">Payment Issues</SelectItem>
                    <SelectItem value="video">Video Submission</SelectItem>
                    <SelectItem value="account">Account Management</SelectItem>
                    <SelectItem value="technical">Technical Support</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-gray-400">Description</FormLabel>
                <FormControl>
                  <Textarea 
                    {...field} 
                    placeholder="Detailed description of your issue" 
                    rows={4}
                    className="bg-matrix-black border-matrix-green/30 focus:border-matrix-green focus:ring-matrix-green/50"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="pt-2">
            <Button 
              type="submit" 
              className="w-full bg-matrix-green text-matrix-black font-bold hover:bg-matrix-darkGreen"
              disabled={mutation.isPending}
            >
              {mutation.isPending ? "Submitting..." : "Submit Ticket"}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default SupportForm;
