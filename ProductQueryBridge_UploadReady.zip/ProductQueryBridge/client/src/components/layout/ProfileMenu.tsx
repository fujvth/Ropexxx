import { useState, useRef, useEffect } from "react";

interface ProfileMenuProps {
  user: any;
  onLogout: () => void;
}

const ProfileMenu = ({ user, onLogout }: ProfileMenuProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div className="relative" ref={menuRef}>
      <button 
        className="relative rounded-full h-10 w-10 bg-matrix-gray border border-matrix-green/50 flex items-center justify-center"
        onClick={() => setIsOpen(!isOpen)}
      >
        <i className="fas fa-user text-matrix-green"></i>
      </button>
      
      {isOpen && (
        <div className="absolute right-0 mt-2 w-64 bg-matrix-gray border border-matrix-green/50 rounded-lg shadow-lg overflow-hidden z-50">
          <div className="p-4 border-b border-matrix-green/20">
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 rounded-full bg-matrix-black border border-matrix-green/50 flex items-center justify-center">
                <i className="fas fa-user text-matrix-green"></i>
              </div>
              <div>
                <p className="text-white font-medium">{user.name}</p>
                <p className="text-xs text-matrix-green">{user.email}</p>
              </div>
            </div>
          </div>
          
          <div className="p-2">
            <a href="#" className="block px-4 py-2 text-gray-300 hover:bg-matrix-black hover:text-matrix-green rounded transition-colors duration-200">
              <i className="fas fa-user-circle mr-2"></i> Your Profile
            </a>
            <a href="#" className="block px-4 py-2 text-gray-300 hover:bg-matrix-black hover:text-matrix-green rounded transition-colors duration-200">
              <i className="fas fa-cog mr-2"></i> Settings
            </a>
            <a href="#" className="block px-4 py-2 text-gray-300 hover:bg-matrix-black hover:text-matrix-green rounded transition-colors duration-200">
              <i className="fas fa-wallet mr-2"></i> Payment History
            </a>
            <div className="border-t border-matrix-green/20 my-2"></div>
            <button 
              onClick={onLogout}
              className="w-full text-left block px-4 py-2 text-gray-300 hover:bg-matrix-black hover:text-red-500 rounded transition-colors duration-200"
            >
              <i className="fas fa-sign-out-alt mr-2"></i> Log Out
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProfileMenu;
