import React from "react";
import { AlertCircle, DollarSign, Ban } from "lucide-react";
import { motion } from "framer-motion";

const PaymentNotice = () => {
  return (
    <motion.div 
      className="my-6 p-5 border-2 border-dashed border-red-500/70 rounded-md bg-gradient-to-r from-transparent to-matrix-black/50"
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex items-start space-x-3">
        <AlertCircle className="text-red-500 h-6 w-6 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="text-red-500 font-bold text-lg tracking-wider">⚠️ CRITICAL PAYMENT INFORMATION ⚠️</h3>
          
          <div className="flex flex-col md:flex-row mt-3 gap-4">
            <div className="flex-1 p-3 bg-matrix-green/10 border border-matrix-green rounded-md">
              <div className="flex items-center">
                <DollarSign className="text-matrix-green h-5 w-5 mr-2" />
                <span className="text-matrix-green font-bold">YOU GET PAID FOR:</span>
              </div>
              <div className="mt-2 pl-4 border-l-2 border-matrix-green">
                <p className="text-white font-bold text-sm">MASTER MANIPULATION BOOK ONLY</p>
                <p className="text-xs text-gray-300 mt-1">
                  When promoting this specific book, your payment will be between $0.10-$0.58 per approved submission.
                </p>
                <a 
                  href="https://books2read.com/u/499gKd" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-block mt-2 text-matrix-green text-xs hover:underline"
                >
                  View the book on Books2Read →
                </a>
              </div>
            </div>
            
            <div className="flex-1 p-3 bg-red-500/10 border border-red-500 rounded-md">
              <div className="flex items-center">
                <Ban className="text-red-500 h-5 w-5 mr-2" />
                <span className="text-red-500 font-bold">NO PAYMENT FOR:</span>
              </div>
              <div className="mt-2 pl-4 border-l-2 border-red-500">
                <p className="text-white font-bold text-sm">ALL OTHER BOOK PROMOTIONS</p>
                <p className="text-xs text-gray-300 mt-1">
                  Videos promoting any other book will be accepted for your portfolio but will NOT generate any payment.
                </p>
              </div>
            </div>
          </div>
          
          <p className="text-xs text-gray-400 mt-4 italic">
            Remember to follow all platform guidelines. Videos must be at least 30 seconds long and showcase the book in a positive light.
          </p>
        </div>
      </div>
    </motion.div>
  );
};

export default PaymentNotice;