import { useQuery } from "@tanstack/react-query";
import { Book } from "@shared/schema";
import MatrixRain from "@/components/animation/MatrixRain";
import { motion } from "framer-motion";

const Books = () => {
  const { data: books, isLoading } = useQuery<Book[]>({
    queryKey: ["/api/books"],
  });
  
  return (
    <div className="relative min-h-screen">
      <MatrixRain />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.h1 
          className="text-3xl font-rajdhani font-bold text-white mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Promotional <span className="text-matrix-green">Books</span>
        </motion.h1>
        
        {isLoading ? (
          <div className="flex justify-center items-center h-40">
            <span className="text-matrix-green">Loading books...</span>
          </div>
        ) : (
          <>
            {books && books.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {books.map((book) => (
                  <motion.div 
                    key={book.id}
                    className="bg-matrix-gray/40 border border-matrix-green/30 rounded-lg overflow-hidden hover:border-matrix-green/60 transition-all duration-300"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-6 flex flex-col justify-center">
                        <h2 className="text-xl font-rajdhani font-bold text-white mb-3">{book.title}</h2>
                        <p className="text-gray-400 text-sm mb-4">{book.description}</p>
                        
                        <div className="space-y-2 mb-4">
                          {Array.isArray(book.features) && book.features.map((feature, index) => (
                            <div className="flex items-center" key={index}>
                              <i className="fas fa-check text-matrix-green mr-2 text-xs"></i>
                              <span className="text-xs text-gray-300">{feature}</span>
                            </div>
                          ))}
                        </div>
                        
                        <motion.button 
                          className="mt-auto bg-matrix-green text-matrix-black font-bold px-4 py-2 rounded-md hover:bg-matrix-darkGreen transition-colors duration-300 text-sm"
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          Unlock Book
                        </motion.button>
                      </div>
                      
                      <div className="flex items-center justify-center p-4">
                        <motion.div 
                          className="perspective-1000"
                          whileHover={{ rotateY: 15 }}
                          transition={{ duration: 0.5 }}
                        >
                          <div className="relative h-56 w-40 mx-auto">
                            <img 
                              src={book.coverImage} 
                              alt={`${book.title} book cover`} 
                              className="h-full w-full object-cover rounded-lg shadow-lg border border-matrix-green/30"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-matrix-black to-transparent opacity-30 rounded-lg"></div>
                          </div>
                        </motion.div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="bg-matrix-gray/40 border border-matrix-green/30 rounded-lg p-8 text-center">
                <div className="text-5xl text-matrix-green mb-4">
                  <i className="fas fa-book"></i>
                </div>
                <h3 className="text-xl font-rajdhani font-bold text-white mb-2">No Books Available</h3>
                <p className="text-gray-400">There are currently no books available for promotion.</p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default Books;
