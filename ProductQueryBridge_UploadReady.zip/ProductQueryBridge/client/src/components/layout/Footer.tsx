import { Link } from "wouter";
import Pill from "@/components/animation/Pill";

const Footer = () => {
  return (
    <footer className="border-t border-matrix-green/30 bg-matrix-black/80 mt-auto">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <Pill />
              <h1 className="text-xl font-rajdhani font-bold text-matrix-green">ROPEX</h1>
            </div>
            <p className="text-sm text-gray-400 mb-4">
              The ultimate platform for book promotion where creators earn money through video submissions.
            </p>
            <div className="flex space-x-4">
              <a href="https://twitter.com/Ropex_Official" target="_blank" rel="noopener noreferrer" className="text-matrix-green hover:text-white transition-colors duration-300">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="https://facebook.com/RopexOfficial" target="_blank" rel="noopener noreferrer" className="text-matrix-green hover:text-white transition-colors duration-300">
                <i className="fab fa-facebook"></i>
              </a>
              <a href="https://instagram.com/ropex_books" target="_blank" rel="noopener noreferrer" className="text-matrix-green hover:text-white transition-colors duration-300">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="https://youtube.com/c/RopexOfficial" target="_blank" rel="noopener noreferrer" className="text-matrix-green hover:text-white transition-colors duration-300">
                <i className="fab fa-youtube"></i>
              </a>
              <a href="https://tiktok.com/@ropexofficial" target="_blank" rel="noopener noreferrer" className="text-matrix-green hover:text-white transition-colors duration-300">
                <i className="fab fa-tiktok"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-rajdhani font-bold text-white mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/">
                  <a className="text-gray-400 hover:text-matrix-green transition-colors duration-300">Dashboard</a>
                </Link>
              </li>
              <li>
                <Link href="/videos">
                  <a className="text-gray-400 hover:text-matrix-green transition-colors duration-300">Submit Videos</a>
                </Link>
              </li>
              <li>
                <Link href="/books">
                  <a className="text-gray-400 hover:text-matrix-green transition-colors duration-300">Book Access</a>
                </Link>
              </li>
              <li>
                <Link href="/support">
                  <a className="text-gray-400 hover:text-matrix-green transition-colors duration-300">Support</a>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-rajdhani font-bold text-white mb-4">Resources</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/videos">
                  <a className="text-gray-400 hover:text-matrix-green transition-colors duration-300">Video Guidelines</a>
                </Link>
              </li>
              <li>
                <Link href="/support">
                  <a className="text-gray-400 hover:text-matrix-green transition-colors duration-300">FAQ</a>
                </Link>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-matrix-green transition-colors duration-300">Terms of Service</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-matrix-green transition-colors duration-300">Privacy Policy</a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-rajdhani font-bold text-white mb-4">Subscribe</h3>
            <p className="text-sm text-gray-400 mb-4">Stay updated with the latest features and releases.</p>
            <form className="flex">
              <input 
                type="email" 
                className="bg-matrix-black border border-matrix-green/30 rounded-l-md px-4 py-2 text-white focus:border-matrix-green focus:outline-none flex-1" 
                placeholder="Your email"
              />
              <button 
                type="submit" 
                className="bg-matrix-green text-matrix-black px-4 py-2 rounded-r-md hover:bg-matrix-darkGreen transition-colors duration-300"
              >
                <i className="fas fa-paper-plane"></i>
              </button>
            </form>
          </div>
        </div>
        
        <div className="border-t border-matrix-green/20 mt-8 pt-6">
          <div className="text-xs text-gray-500 mb-4">
            <h4 className="text-sm text-matrix-green mb-2 font-bold">Platform Rules:</h4>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <li>• Only submit videos for approved books on our platform</li>
              <li>• Content must be family-friendly and appropriate</li>
              <li>• No misleading or false information about books</li>
              <li>• Videos must be at least 30 seconds in length</li>
              <li>• You must own rights to all content submitted</li>
              <li>• No spam, bots, or automated submissions</li>
              <li>• Payment processing occurs after approval</li>
              <li>• Minimum payout threshold is $20.00</li>
            </ul>
          </div>
          <p className="text-xs text-gray-500 text-center">&copy; {new Date().getFullYear()} ROPEX. All rights reserved. <span className="text-matrix-green">BE UNBELIEVABLE.</span></p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
