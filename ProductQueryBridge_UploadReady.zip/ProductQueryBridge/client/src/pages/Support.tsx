import MatrixRain from "@/components/animation/MatrixRain";
import SupportForm from "@/components/support/SupportForm";
import FaqSection from "@/components/support/FaqSection";
import { useQuery } from "@tanstack/react-query";
import { SupportTicket } from "@shared/schema";
import { motion } from "framer-motion";

const Support = () => {
  const { data: tickets, isLoading } = useQuery<SupportTicket[]>({
    queryKey: ["/api/support-tickets"],
  });
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "open":
        return <span className="px-2 py-1 rounded-full bg-yellow-500/20 text-yellow-500 text-xs">Open</span>;
      case "in_progress":
        return <span className="px-2 py-1 rounded-full bg-blue-500/20 text-blue-500 text-xs">In Progress</span>;
      case "closed":
        return <span className="px-2 py-1 rounded-full bg-green-500/20 text-green-500 text-xs">Closed</span>;
      default:
        return <span className="px-2 py-1 rounded-full bg-gray-500/20 text-gray-500 text-xs">Unknown</span>;
    }
  };
  
  const getCategoryLabel = (category: string) => {
    switch (category) {
      case "payment":
        return "Payment Issues";
      case "video":
        return "Video Submission";
      case "account":
        return "Account Management";
      case "technical":
        return "Technical Support";
      default:
        return category;
    }
  };
  
  return (
    <div className="relative min-h-screen">
      <MatrixRain />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.h1 
          className="text-3xl font-rajdhani font-bold text-white mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Help & <span className="text-matrix-green">Support</span>
        </motion.h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <SupportForm />
          <FaqSection />
        </div>
        
        <div className="mt-12">
          <h2 className="text-2xl font-rajdhani font-bold text-white mb-6">Your Support Tickets</h2>
          
          {isLoading ? (
            <div className="flex justify-center items-center h-40">
              <span className="text-matrix-green">Loading tickets...</span>
            </div>
          ) : (
            <>
              {tickets && tickets.length > 0 ? (
                <div className="bg-matrix-gray border border-matrix-green/30 rounded-lg overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-matrix-black/50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">ID</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Subject</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Category</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Status</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Date</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-matrix-green/10">
                        {tickets.map((ticket) => (
                          <tr key={ticket.id} className="hover:bg-matrix-black/20">
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-matrix-green">#{ticket.id}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-white">{ticket.subject}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">{getCategoryLabel(ticket.category)}</td>
                            <td className="px-6 py-4 whitespace-nowrap">{getStatusBadge(ticket.status)}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">
                              {new Date(ticket.createdAt).toLocaleDateString()}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ) : (
                <div className="bg-matrix-gray/40 border border-matrix-green/30 rounded-lg p-8 text-center">
                  <div className="text-5xl text-matrix-green mb-4">
                    <i className="fas fa-ticket-alt"></i>
                  </div>
                  <h3 className="text-xl font-rajdhani font-bold text-white mb-2">No Support Tickets</h3>
                  <p className="text-gray-400 mb-6">You haven't created any support tickets yet.</p>
                  <p className="text-sm text-gray-500">If you need help, please submit a new ticket using the form above.</p>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Support;
