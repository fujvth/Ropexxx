import { motion } from "framer-motion";

interface ProgressBarProps {
  current: number;
  goal: number;
}

const ProgressBar = ({ current, goal }: ProgressBarProps) => {
  const percent = Math.min(100, Math.round((current / goal) * 100));
  
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm text-gray-400">Progress to ${goal.toFixed(2)} goal:</span>
        <span className="text-matrix-green font-medium">
          ${current.toFixed(2)} / ${goal.toFixed(2)}
        </span>
      </div>
      <div className="h-4 bg-matrix-black/50 rounded-full overflow-hidden">
        <motion.div 
          className="h-full bg-gradient-to-r from-pill-red to-pill-blue rounded-full"
          initial={{ width: "0%" }}
          animate={{ width: `${percent}%` }}
          transition={{ duration: 1.5, ease: "easeOut" }}
        />
      </div>
      <p className="text-xs text-right mt-1 text-gray-400">{percent}% Complete</p>
    </div>
  );
};

export default ProgressBar;
