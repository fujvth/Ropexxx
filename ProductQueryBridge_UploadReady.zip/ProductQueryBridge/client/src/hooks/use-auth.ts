import { useState, useEffect } from "react";
import { apiRequest } from "@/lib/queryClient";

export interface User {
  id: number;
  username: string;
  name: string;
  email: string;
  isAdmin: boolean;
}

interface AuthHook {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (username: string, password: string) => Promise<User>;
  logout: () => Promise<void>;
  register: (userData: {
    username: string;
    password: string;
    name: string;
    email: string;
  }) => Promise<User>;
  checkAuth: () => Promise<User | null>;
}

export const useAuth = (): AuthHook => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const checkAuth = async (): Promise<User | null> => {
    try {
      const res = await fetch("/api/auth/me", {
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 401) {
          return null;
        }
        throw new Error(`Error checking auth: ${res.statusText}`);
      }
      
      const userData = await res.json();
      setUser(userData);
      return userData;
    } catch (error) {
      console.error("Error checking auth:", error);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    checkAuth();
  }, []);

  const login = async (username: string, password: string): Promise<User> => {
    try {
      setIsLoading(true);
      const res = await apiRequest("POST", "/api/auth/login", { username, password });
      const userData = await res.json();
      setUser(userData);
      return userData;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async (): Promise<void> => {
    try {
      setIsLoading(true);
      await apiRequest("POST", "/api/auth/logout", {});
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (userData: {
    username: string;
    password: string;
    name: string;
    email: string;
  }): Promise<User> => {
    try {
      setIsLoading(true);
      const res = await apiRequest("POST", "/api/auth/register", userData);
      const newUser = await res.json();
      setUser(newUser);
      return newUser;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
    login,
    logout,
    register,
    checkAuth
  };
};

export default useAuth;
