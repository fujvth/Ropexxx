import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertVideoSchema, 
  insertSupportTicketSchema 
} from "@shared/schema";
import session from "express-session";
import MemoryStore from "memorystore";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { WebSocketServer, WebSocket } from "ws";
import { generateRandomPayment } from "@/lib/matrix-utils";

const MemoryStoreSession = MemoryStore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup session
  app.use(
    session({
      secret: "dataoracle-secret",
      resave: false,
      saveUninitialized: false,
      store: new MemoryStoreSession({
        checkPeriod: 86400000, // Prune expired entries every 24h
      }),
      cookie: {
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
      },
    })
  );

  // Setup passport authentication
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Incorrect username" });
        }
        if (user.password !== password) { // In a real app, use bcrypt to compare passwords
          return done(null, false, { message: "Incorrect password" });
        }
        return done(null, user);
      } catch (err) {
        return done(err);
      }
    })
  );

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  // Auth middleware
  const isAuthenticated = (req: Request, res: Response, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Not authenticated" });
  };

  const isAdmin = (req: Request, res: Response, next: any) => {
    if (req.isAuthenticated() && (req.user as any)?.isAdmin) {
      return next();
    }
    res.status(403).json({ message: "Not authorized" });
  };

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already taken" });
      }
      
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already in use" });
      }
      
      const user = await storage.createUser(userData);
      
      // Auto login after registration
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ message: "Error logging in after registration" });
        }
        return res.status(201).json({ id: user.id, username: user.username, name: user.name, email: user.email });
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/login", (req, res, next) => {
    passport.authenticate("local", (err: Error | null, user: any, info: { message?: string } | undefined) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(401).json({ message: info?.message || "Invalid username or password" });
      }
      req.login(user, (err) => {
        if (err) {
          return next(err);
        }
        return res.json({ 
          id: user.id, 
          username: user.username, 
          name: user.name, 
          email: user.email, 
          isAdmin: user.isAdmin 
        });
      });
    })(req, res, next);
  });

  app.post("/api/auth/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) {
        return next(err);
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", isAuthenticated, (req, res) => {
    const user = req.user as any;
    res.json({ id: user.id, username: user.username, name: user.name, email: user.email, isAdmin: user.isAdmin });
  });

  // User routes
  app.get("/api/users/me/balance", isAuthenticated, async (req, res) => {
    const userId = (req.user as any).id;
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    res.json({ balance: user.balance });
  });

  // Video routes
  app.get("/api/videos", isAuthenticated, async (req, res) => {
    const userId = (req.user as any).id;
    const videos = await storage.getUserVideos(userId);
    res.json(videos);
  });

  // Video submission endpoint was moved to the bottom to include payment processing

  app.get("/api/videos/:id", isAuthenticated, async (req, res) => {
    const videoId = parseInt(req.params.id);
    const video = await storage.getVideo(videoId);
    
    if (!video) {
      return res.status(404).json({ message: "Video not found" });
    }
    
    // Increment view count
    await storage.updateVideoViews(videoId, video.views + 1);
    
    res.json(video);
  });

  // Admin video routes
  app.get("/api/admin/videos", isAdmin, async (req, res) => {
    const videos = await storage.getAllVideos();
    res.json(videos);
  });

  app.patch("/api/admin/videos/:id/status", isAdmin, async (req, res) => {
    const videoId = parseInt(req.params.id);
    const { status } = req.body;
    
    if (!status || !["pending", "approved", "rejected"].includes(status)) {
      return res.status(400).json({ message: "Invalid status" });
    }
    
    const updatedVideo = await storage.updateVideoStatus(videoId, status);
    
    if (!updatedVideo) {
      return res.status(404).json({ message: "Video not found" });
    }
    
    res.json(updatedVideo);
  });

  // Book routes
  app.get("/api/books", async (req, res) => {
    const books = await storage.getAllBooks();
    res.json(books);
  });

  app.get("/api/books/:id", async (req, res) => {
    const bookId = parseInt(req.params.id);
    const book = await storage.getBook(bookId);
    
    if (!book) {
      return res.status(404).json({ message: "Book not found" });
    }
    
    res.json(book);
  });

  // Support ticket routes
  app.get("/api/support-tickets", isAuthenticated, async (req, res) => {
    const userId = (req.user as any).id;
    const tickets = await storage.getUserSupportTickets(userId);
    res.json(tickets);
  });

  app.post("/api/support-tickets", isAuthenticated, async (req, res) => {
    try {
      const ticketData = insertSupportTicketSchema.parse(req.body);
      const userId = (req.user as any).id;
      const ticket = await storage.createSupportTicket(ticketData, userId);
      res.status(201).json(ticket);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Admin support ticket routes
  app.get("/api/admin/support-tickets", isAdmin, async (req, res) => {
    const tickets = await storage.getAllSupportTickets();
    res.json(tickets);
  });

  app.patch("/api/admin/support-tickets/:id/status", isAdmin, async (req, res) => {
    const ticketId = parseInt(req.params.id);
    const { status } = req.body;
    
    if (!status || !["open", "in_progress", "closed"].includes(status)) {
      return res.status(400).json({ message: "Invalid status" });
    }
    
    const updatedTicket = await storage.updateSupportTicketStatus(ticketId, status);
    
    if (!updatedTicket) {
      return res.status(404).json({ message: "Ticket not found" });
    }
    
    res.json(updatedTicket);
  });

  // Notification routes
  app.get("/api/notifications", isAuthenticated, async (req, res) => {
    const userId = (req.user as any).id;
    const notifications = await storage.getUserNotifications(userId);
    res.json(notifications);
  });

  app.patch("/api/notifications/:id/read", isAuthenticated, async (req, res) => {
    const notificationId = parseInt(req.params.id);
    const updatedNotification = await storage.markNotificationAsRead(notificationId);
    
    if (!updatedNotification) {
      return res.status(404).json({ message: "Notification not found" });
    }
    
    res.json(updatedNotification);
  });

  const httpServer = createServer(app);
  
  // Setup WebSocket server on a different path to avoid conflicts with Vite HMR
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Store active connections
  const clients = new Map<number, WebSocket>();
  
  wss.on('connection', (ws) => {
    console.log('WebSocket client connected');
    
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        // Handle authentication
        if (data.type === 'auth') {
          const userId = data.userId;
          if (userId) {
            clients.set(userId, ws);
            console.log(`User ${userId} authenticated with WebSocket`);
            
            // Send initial data
            const user = await storage.getUser(userId);
            if (user) {
              ws.send(JSON.stringify({
                type: 'balance',
                balance: user.balance
              }));
            }
          }
        }
      } catch (err) {
        console.error('Error processing WebSocket message:', err);
      }
    });
    
    ws.on('close', () => {
      // Remove client on disconnect
      const entries = Array.from(clients.entries());
      for (const [userId, client] of entries) {
        if (client === ws) {
          clients.delete(userId);
          console.log(`User ${userId} disconnected from WebSocket`);
          break;
        }
      }
    });
  });
  
  // Modify the video submission endpoint to process payments in real-time
  // Only pay for videos promoting the MASTER MANIPULATION book (id: 2)
  app.post("/api/videos", isAuthenticated, async (req, res) => {
    try {
      const videoData = insertVideoSchema.parse(req.body);
      const userId = (req.user as any).id;
      const video = await storage.createVideo(videoData, userId);
      
      // Check if video is promoting the "MASTER MANIPULATION" book (id: 2)
      const isPromotingMasterManipulation = video.bookId === 2;
      
      if (isPromotingMasterManipulation) {
        // Generate a random payment amount
        const paymentAmount = generateRandomPayment();
        
        // Update user balance
        const user = await storage.getUser(userId);
        if (user) {
          const newBalance = user.balance + paymentAmount;
          await storage.updateUserBalance(userId, newBalance);
          
          // Create notification for payment
          await storage.createNotification({
            title: "Payment Received",
            message: `You received $${paymentAmount.toFixed(2)} for promoting MASTER MANIPULATION with your video "${video.title}"`,
            type: "payment",
            userId
          });
          
          // Send real-time update via WebSocket if user is connected
          const ws = clients.get(userId);
          if (ws && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({
              type: 'payment',
              amount: paymentAmount,
              balance: newBalance,
              videoId: video.id,
              videoTitle: video.title
            }));
          }
        }
      } else {
        // Set payment to 0 for videos not promoting MASTER MANIPULATION
        await storage.updateVideoPayment(video.id, 0);
        
        // Create notification for zero payment
        await storage.createNotification({
          title: "Video Submitted - No Payment",
          message: `Your video "${video.title}" was submitted, but no payment was issued as it does not promote MASTER MANIPULATION book.`,
          type: "general",
          userId
        });
      }
      
      res.status(201).json(video);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });
  
  return httpServer;
}
