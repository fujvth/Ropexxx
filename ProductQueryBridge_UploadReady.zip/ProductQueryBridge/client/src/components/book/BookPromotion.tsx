import { useQuery } from "@tanstack/react-query";
import { Book } from "@shared/schema";
import { motion } from "framer-motion";

const BookPromotion = () => {
  const { data: books } = useQuery<Book[]>({
    queryKey: ["/api/books"],
  });
  
  if (!books || books.length === 0) {
    return null;
  }
  
  // Just show the first book for now
  const book = books[0];
  
  return (
    <section className="mb-12 bg-gradient-to-r from-matrix-gray to-matrix-black border border-matrix-green/30 rounded-lg p-6 animate-fade-in">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1 flex flex-col justify-center">
          <h2 className="text-2xl md:text-3xl font-rajdhani font-bold text-white mb-4">
            {book.title.split(' ').map((word, i) => 
              i % 3 === 0 ? <span key={i} className="text-matrix-green">{word} </span> : `${word} `
            )}
          </h2>
          
          <p className="text-gray-300 mb-6">{book.description}</p>
          
          <div className="space-y-4">
            {Array.isArray(book.features) && book.features.map((feature, index) => (
              <div className="flex items-center" key={index}>
                <i className="fas fa-check text-matrix-green mr-3"></i>
                <span className="text-sm text-gray-300">{feature}</span>
              </div>
            ))}
          </div>
          
          <motion.button 
            className="mt-6 bg-matrix-green text-matrix-black font-bold px-6 py-3 rounded-md hover:bg-matrix-darkGreen transition-colors duration-300 w-full md:w-auto"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Unlock Book Access
          </motion.button>
        </div>
        
        <div className="md:col-span-2 flex justify-center items-center">
          <motion.div 
            className="perspective-1000"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
          >
            <motion.div 
              className="relative w-64 h-80 book-container"
              whileHover={{ rotateY: 15 }}
              transition={{ duration: 0.5 }}
            >
              <img 
                src={book.coverImage} 
                alt={`${book.title} book cover`} 
                className="rounded-lg shadow-2xl border border-matrix-green/40 h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-matrix-black to-transparent opacity-40 rounded-lg"></div>
              <div className="absolute bottom-4 left-0 right-0 text-center">
                <span className="inline-block bg-matrix-green text-matrix-black px-3 py-1 rounded-full text-sm font-bold">
                  Premium Content
                </span>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default BookPromotion;
