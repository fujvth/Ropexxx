import { useQuery } from "@tanstack/react-query";
import { Video, Book } from "@shared/schema";
import MatrixRain from "@/components/animation/MatrixRain";
import VideoSubmissionForm from "@/components/video/VideoSubmissionForm";
import VideoCard from "@/components/video/VideoCard";
import { motion } from "framer-motion";
import { generateRandomPayment } from "@/lib/matrix-utils";
import { useState } from "react";

const Videos = () => {
  const { data: videos, isLoading: videosLoading } = useQuery<Video[]>({
    queryKey: ["/api/videos"],
  });
  
  const { data: books, isLoading: booksLoading } = useQuery<Book[]>({
    queryKey: ["/api/books"],
  });
  
  const isLoading = videosLoading || booksLoading;
  
  const [refreshKey, setRefreshKey] = useState(0);
  
  // Handler for successful video submission to refresh the video list
  const handleVideoSubmissionSuccess = () => {
    setRefreshKey(prevKey => prevKey + 1);
  };
  
  const getCategoryLabel = (category: string) => {
    switch (category) {
      case "book-promotion":
        return "Book Promotion";
      case "digital-marketing":
        return "Digital Marketing";
      case "video-creation":
        return "Video Creation";
      case "payment-concept":
        return "Payment Concept";
      default:
        return category;
    }
  };
  
  const getStatusLabel = (status: string) => {
    return status.charAt(0).toUpperCase() + status.slice(1);
  };
  
  const approvedVideos = videos?.filter(video => video.status === "approved") || [];
  const pendingVideos = videos?.filter(video => video.status === "pending") || [];
  const rejectedVideos = videos?.filter(video => video.status === "rejected") || [];
  
  return (
    <div className="relative min-h-screen">
      <MatrixRain />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div 
          className="mb-6 p-4 bg-gradient-to-r from-matrix-green/10 to-matrix-black border-l-4 border-matrix-green rounded-md"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h3 className="text-white font-bold flex items-center">
            <span className="text-matrix-green text-lg mr-2">💲</span>
            EXCLUSIVE PROMOTION OPPORTUNITY
          </h3>
          <p className="text-gray-300 mt-1">
            Earn real money by promoting <span className="font-bold text-matrix-green">MASTER MANIPULATION</span> with your videos!
            <a 
              href="https://books2read.com/u/499gKd" 
              target="_blank" 
              rel="noopener noreferrer"
              className="ml-2 text-matrix-green hover:underline"
            >
              View on Books2Read →
            </a>
          </p>
        </motion.div>
        
        <motion.h1 
          className="text-3xl font-rajdhani font-bold text-white mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          Your Video <span className="text-matrix-green">Submissions</span>
        </motion.h1>
        
        {books && books.length > 0 ? (
          <VideoSubmissionForm 
            books={books?.map(book => ({
              id: book.id,
              title: book.title,
              description: book.description
            }))} 
            onSuccess={handleVideoSubmissionSuccess} 
          />
        ) : (
          <div className="mb-8 p-4 bg-matrix-black border border-matrix-green/30 rounded-lg">
            <p className="text-matrix-green text-center">
              <i className="fas fa-circle-notch fa-spin mr-2"></i>
              Loading book data...
            </p>
          </div>
        )}
        
        {isLoading ? (
          <div className="flex justify-center items-center h-40">
            <span className="text-matrix-green">Loading videos...</span>
          </div>
        ) : (
          <>
            {pendingVideos.length > 0 && (
              <section className="mb-12">
                <div className="flex items-center mb-6">
                  <h2 className="text-2xl font-rajdhani font-bold text-white">Pending Review</h2>
                  <div className="ml-3 px-2 py-1 rounded-full bg-yellow-500/20 text-yellow-500 text-xs">
                    {pendingVideos.length} {pendingVideos.length === 1 ? "video" : "videos"}
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {pendingVideos.map(video => (
                    <VideoCard key={video.id} video={video} />
                  ))}
                </div>
              </section>
            )}
            
            {approvedVideos.length > 0 && (
              <section className="mb-12">
                <div className="flex items-center mb-6">
                  <h2 className="text-2xl font-rajdhani font-bold text-white">Approved Videos</h2>
                  <div className="ml-3 px-2 py-1 rounded-full bg-matrix-green/20 text-matrix-green text-xs">
                    {approvedVideos.length} {approvedVideos.length === 1 ? "video" : "videos"}
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {approvedVideos.map(video => (
                    <VideoCard key={video.id} video={video} />
                  ))}
                </div>
              </section>
            )}
            
            {rejectedVideos.length > 0 && (
              <section className="mb-12">
                <div className="flex items-center mb-6">
                  <h2 className="text-2xl font-rajdhani font-bold text-white">Rejected Videos</h2>
                  <div className="ml-3 px-2 py-1 rounded-full bg-red-500/20 text-red-500 text-xs">
                    {rejectedVideos.length} {rejectedVideos.length === 1 ? "video" : "videos"}
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {rejectedVideos.map(video => (
                    <VideoCard key={video.id} video={video} />
                  ))}
                </div>
              </section>
            )}
            
            {videos && videos.length === 0 && (
              <div className="bg-matrix-gray/40 border border-matrix-green/30 rounded-lg p-8 text-center">
                <div className="text-5xl text-matrix-green mb-4">
                  <i className="fas fa-video-slash"></i>
                </div>
                <h3 className="text-xl font-rajdhani font-bold text-white mb-2">No Videos Yet</h3>
                <p className="text-gray-400 mb-6">You haven't submitted any videos for review yet.</p>
                <p className="text-sm text-gray-500">Submit your first video to start earning rewards!</p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default Videos;
