import { motion } from "framer-motion";

interface PillProps {
  color?: 'red' | 'blue';
  onClick?: () => void;
}

const Pill: React.FC<PillProps> = ({ color = 'blue', onClick }) => {
  return (
    <div className="pill-container perspective-1000" onClick={onClick}>
      <motion.div 
        className="relative h-10 w-24 transform-style-preserve-3d cursor-pointer"
        whileHover={{ rotateY: 180 }}
        transition={{ duration: 0.5 }}
      >
        <div className={`absolute w-full h-full rounded-full ${color === 'red' ? 'bg-gradient-to-r from-pill-red to-red-700' : 'bg-gradient-to-r from-pill-blue to-blue-700'} flex items-center justify-center text-xs text-white font-bold backface-hidden`}>
          {color === 'red' ? 'Red Pill' : 'Blue Pill'}
        </div>
        <div className={`absolute w-full h-full rounded-full ${color === 'red' ? 'bg-gradient-to-r from-red-700 to-pill-red' : 'bg-gradient-to-r from-blue-700 to-pill-blue'} flex items-center justify-center text-xs text-white font-bold backface-hidden rotate-y-180`}>
          Choose Wisely
        </div>
      </motion.div>
    </div>
  );
};

export default Pill;
