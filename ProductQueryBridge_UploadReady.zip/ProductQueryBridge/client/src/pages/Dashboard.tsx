import { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import MatrixRain from "@/components/animation/MatrixRain";
import StatsCard from "@/components/dashboard/StatsCard";
import ProgressBar from "@/components/dashboard/ProgressBar";
import VideoSubmissionForm from "@/components/video/VideoSubmissionForm";
import VideoCard from "@/components/video/VideoCard";
import BookPromotion from "@/components/book/BookPromotion";
import { Video, User, Book } from "@shared/schema";
import { useWebSocket } from "@/hooks/use-websocket";
import { useToast } from "@/hooks/use-toast";

// Type guards for API responses
interface BalanceResponse {
  balance: number;
}

function isUser(obj: any): obj is User {
  return obj && typeof obj === 'object' && 'name' in obj && 'id' in obj;
}

function isBalanceResponse(obj: any): obj is BalanceResponse {
  return obj && typeof obj === 'object' && 'balance' in obj;
}

const Dashboard = () => {
  const [userName, setUserName] = useState<string>("");
  const [userBalanceValue, setUserBalanceValue] = useState<number>(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { isConnected, lastMessage } = useWebSocket();
  
  const { data: user } = useQuery<User>({
    queryKey: ["/api/auth/me"],
  });
  
  const { data: userBalance } = useQuery<BalanceResponse>({
    queryKey: ["/api/users/me/balance"]
  });
  
  // Update balance when data is received
  useEffect(() => {
    if (userBalance && 'balance' in userBalance) {
      setUserBalanceValue(userBalance.balance);
    }
  }, [userBalance]);
  
  const { data: videos } = useQuery<Video[]>({
    queryKey: ["/api/videos"],
  });
  
  const { data: books } = useQuery<Book[]>({
    queryKey: ["/api/books"],
  });
  
  // Handle WebSocket messages for real-time balance updates
  useEffect(() => {
    if (lastMessage) {
      if (lastMessage.type === 'balance') {
        setUserBalanceValue(lastMessage.balance);
      } else if (lastMessage.type === 'payment') {
        setUserBalanceValue(lastMessage.balance);
        // Invalidate queries to refresh the data
        queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
        toast({
          title: "Payment Received!",
          description: `You received $${lastMessage.amount.toFixed(2)} for your video submission.`,
          variant: "default"
        });
      }
    }
  }, [lastMessage, queryClient, toast]);
  
  useEffect(() => {
    if (user?.name) {
      setUserName(user.name);
    }
  }, [user]);
  
  // Calculate stats
  const videoCount = videos?.length || 0;
  const avgPayment = videos && videos.length > 0 
    ? videos.reduce((sum, video) => sum + (video.payment || 0), 0) / videos.length 
    : 0;
  const daysActive = user?.joinDate
    ? Math.ceil((new Date().getTime() - new Date(user.joinDate).getTime()) / (1000 * 60 * 60 * 24))
    : 0;
  
  return (
    <div className="relative min-h-screen">
      <MatrixRain />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <section className="mb-12 animate-fade-in">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
            <div>
              <motion.h2 
                className="text-3xl font-rajdhani font-bold text-white mb-2"
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                Welcome, <span className="text-matrix-green">{userName}</span>
              </motion.h2>
              <motion.p 
                className="text-gray-400 matrix-typing"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3, duration: 0.5 }}
              >
                Your journey to unbelievable results begins here.
              </motion.p>
            </div>
            
            <motion.div 
              className="mt-4 md:mt-0 bg-matrix-gray border border-matrix-green/30 rounded-lg p-4 w-full md:w-auto"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.5 }}
            >
              <ProgressBar current={userBalanceValue} goal={20} />
            </motion.div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <StatsCard 
              title="Submitted Videos" 
              value={videoCount} 
              icon="fa-video"
              trend={{
                value: "12%",
                label: "from last week",
                isPositive: true
              }}
            />
            
            <StatsCard 
              title="Average Payment" 
              value={`$${avgPayment.toFixed(2)}`} 
              icon="fa-dollar-sign"
              trend={{
                value: "5%",
                label: "from last payment",
                isPositive: true
              }}
            />
            
            <StatsCard 
              title="Days Active" 
              value={daysActive} 
              icon="fa-calendar-check"
            />
          </div>
        </section>
        
        <VideoSubmissionForm books={books?.map(book => ({
          id: book.id,
          title: book.title,
          description: book.description,
          author: book.author
        })) || []} />
        
        <section className="mb-12 animate-fade-in">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-rajdhani font-bold text-white">Recent Submissions</h2>
            <a href="/videos" className="text-matrix-green hover:text-white transition-colors duration-300 text-sm">View All <i className="fas fa-arrow-right ml-1"></i></a>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {videos && videos.length > 0 ? (
              videos.slice(0, 3).map((video) => (
                <VideoCard key={video.id} video={video} />
              ))
            ) : (
              <div className="col-span-3 text-center py-8 text-gray-400">
                You haven't submitted any videos yet. Get started by submitting your first video!
              </div>
            )}
          </div>
        </section>
        
        <BookPromotion />
      </div>
    </div>
  );
};

export default Dashboard;
