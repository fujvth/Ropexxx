import { motion } from "framer-motion";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: string;
  trend?: {
    value: string;
    label: string;
    isPositive: boolean;
  };
}

const StatsCard = ({ title, value, icon, trend }: StatsCardProps) => {
  return (
    <motion.div 
      className="bg-matrix-gray border border-matrix-green/30 rounded-lg p-6 hover:border-matrix-green/60 transition-all duration-300"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex justify-between items-start">
        <div>
          <p className="text-gray-400 text-sm mb-1">{title}</p>
          <h3 className="text-3xl font-rajdhani font-bold text-white">{value}</h3>
        </div>
        <div className="bg-matrix-black/30 p-3 rounded-lg">
          <i className={`fas ${icon} text-matrix-green`}></i>
        </div>
      </div>
      {trend && (
        <div className="mt-4">
          <div className="flex items-center text-xs">
            <span className={`${trend.isPositive ? 'text-green-400' : 'text-red-400'} mr-1`}>
              <i className={`fas ${trend.isPositive ? 'fa-arrow-up' : 'fa-arrow-down'}`}></i> {trend.value}
            </span>
            <span className="text-gray-400">{trend.label}</span>
          </div>
        </div>
      )}
    </motion.div>
  );
};

export default StatsCard;
