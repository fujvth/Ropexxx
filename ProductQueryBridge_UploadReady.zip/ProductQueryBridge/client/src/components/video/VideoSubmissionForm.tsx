import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { insertVideoSchema } from '@shared/schema';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useWebSocket } from '@/hooks/use-websocket';
import { motion } from 'framer-motion';
import { matrixFadeIn } from '@/lib/matrix-utils';
import PaymentNotice from './PaymentNotice';

// Extend the video schema with validation
const videoSubmissionSchema = insertVideoSchema.extend({
  title: z.string().min(5, 'Title must be at least 5 characters'),
  description: z.string().min(20, 'Description must be at least 20 characters'),
  link: z.string().url('Please enter a valid video URL'),
  bookId: z.number().positive('Please select a book to promote'),
  category: z.string().default('book-promotion'),
});

type VideoSubmissionFormValues = z.infer<typeof videoSubmissionSchema>;

interface BookForForm {
  id: number;
  title: string;
  description?: string;
  author?: string | null;
}

interface VideoSubmissionFormProps {
  books: BookForForm[];
  onSuccess?: () => void;
}

const VideoSubmissionForm = ({ books, onSuccess }: VideoSubmissionFormProps) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { isConnected, lastMessage } = useWebSocket();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionResult, setSubmissionResult] = useState<{
    success: boolean;
    amount?: number;
    balance?: number;
  } | null>(null);

  const form = useForm<VideoSubmissionFormValues>({
    resolver: zodResolver(videoSubmissionSchema),
    defaultValues: {
      title: '',
      description: '',
      link: '',
      bookId: undefined,
      category: 'book-promotion',
    },
  });

  // Process WebSocket messages for real-time updates
  useEffect(() => {
    if (lastMessage && lastMessage.type === 'payment') {
      setSubmissionResult({
        success: true,
        amount: lastMessage.amount,
        balance: lastMessage.balance,
      });
      
      toast({
        title: 'Payment Received!',
        description: `You received $${lastMessage.amount?.toFixed(2)} for your video submission.`,
      });
      
      // Reset form after successful submission
      form.reset();
      
      // If onSuccess callback is provided, call it
      if (onSuccess) {
        onSuccess();
      }
      
      setIsSubmitting(false);
    }
  }, [lastMessage, form, onSuccess, toast]);

  const onSubmit = async (values: VideoSubmissionFormValues) => {
    try {
      setIsSubmitting(true);
      
      await apiRequest('POST', '/api/videos', values);
      
      // Success notification will now come from the WebSocket
      // We'll show a loading state until the WebSocket sends us the payment details
      
      toast({
        title: 'Video Submitted',
        description: 'Your video is being processed. Payment will be credited shortly.',
      });
      
      // The form reset and success callback will happen when we receive the WebSocket message
      
    } catch (error: any) {
      toast({
        title: 'Submission Failed',
        description: error.message || 'There was an error submitting your video. Please try again.',
        variant: 'destructive',
      });
      setIsSubmitting(false);
    }
  };

  return (
    <motion.div
      className="w-full max-w-2xl mx-auto bg-matrix-black border border-matrix-green/30 rounded-lg p-6 shadow-lg"
      initial="hidden"
      animate="visible"
      variants={matrixFadeIn}
    >
      <h2 className="text-2xl font-bold text-matrix-green mb-6">Submit a Promotional Video</h2>
      <PaymentNotice />
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-white">Video Title</FormLabel>
                <FormControl>
                  <Input 
                    {...field} 
                    placeholder="Enter a catchy title for your promo video" 
                    className="border-matrix-green/30 focus:border-matrix-green focus:ring-matrix-green/50"
                    style={{ color: "black", backgroundColor: "white" }}
                  />
                </FormControl>
                <FormMessage className="text-red-400" />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-white">Video Description</FormLabel>
                <FormControl>
                  <Textarea 
                    {...field} 
                    placeholder="Describe how your video promotes the book" 
                    className="border-matrix-green/30 focus:border-matrix-green focus:ring-matrix-green/50 min-h-[100px]"
                    style={{ color: "black", backgroundColor: "white" }}
                  />
                </FormControl>
                <FormMessage className="text-red-400" />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="link"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-white">Video URL</FormLabel>
                <FormControl>
                  <Input 
                    {...field} 
                    placeholder="Paste the URL to your video (YouTube, Vimeo, etc.)" 
                    className="border-matrix-green/30 focus:border-matrix-green focus:ring-matrix-green/50"
                    style={{ color: "black", backgroundColor: "white" }}
                  />
                </FormControl>
                <FormMessage className="text-red-400" />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="bookId"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-white">Book to Promote</FormLabel>
                <Select
                  onValueChange={(value) => field.onChange(parseInt(value))}
                  defaultValue={field.value?.toString()}
                >
                  <FormControl>
                    <SelectTrigger className="border-matrix-green/30 focus:border-matrix-green focus:ring-matrix-green/50 text-white bg-matrix-black">
                      <SelectValue placeholder="Select a book to promote" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent className="border-matrix-green/30 bg-matrix-black text-white">
                    {books.map((book) => (
                      <SelectItem key={book.id} value={book.id.toString()} className="text-white hover:bg-matrix-green/20">
                        {book.title} {book.author ? `by ${book.author}` : ''}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage className="text-red-400" />
              </FormItem>
            )}
          />
          
          <div className="py-4">
            <div className="text-sm text-matrix-green mb-2">
              <i className="fas fa-info-circle mr-2"></i>
              By submitting this video, you'll earn a reward when it's approved.
            </div>
            {isConnected ? (
              <div className="text-xs text-green-400">
                <i className="fas fa-plug mr-1"></i> Connected to real-time payment system
              </div>
            ) : (
              <div className="text-xs text-yellow-400">
                <i className="fas fa-exclamation-triangle mr-1"></i> Not connected to real-time payment system
              </div>
            )}
          </div>
          
          <Button 
            type="submit" 
            className="w-full bg-matrix-green text-black font-bold hover:bg-matrix-green/80"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <>
                <span className="mr-2">Processing</span>
                <i className="fas fa-spinner fa-spin"></i>
              </>
            ) : (
              'Submit Video'
            )}
          </Button>
        </form>
      </Form>
      
      {submissionResult && submissionResult.success && (
        <motion.div 
          className="mt-6 p-4 bg-matrix-green/20 border border-matrix-green rounded-md animate-pulse"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h3 className="text-xl font-bold text-matrix-green">Payment Received!</h3>
          <p className="text-white mt-2">
            You've earned <span className="font-bold text-matrix-green">${submissionResult.amount?.toFixed(2)}</span> for your video submission.
          </p>
          <p className="text-white mt-1">
            Your new balance: <span className="font-bold text-matrix-green">${submissionResult.balance?.toFixed(2)}</span>
          </p>
        </motion.div>
      )}
    </motion.div>
  );
};

export default VideoSubmissionForm;