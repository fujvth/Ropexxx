import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Video, SupportTicket } from "@shared/schema";
import MatrixRain from "@/components/animation/MatrixRain";
import { motion } from "framer-motion";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

const AdminDashboard = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("videos");

  // Fetch all videos
  const { data: videos, isLoading: videosLoading } = useQuery<Video[]>({
    queryKey: ["/api/admin/videos"],
  });

  // Fetch all support tickets
  const { data: tickets, isLoading: ticketsLoading } = useQuery<SupportTicket[]>({
    queryKey: ["/api/admin/support-tickets"],
  });

  // Video approval/rejection handler
  const handleVideoStatus = async (videoId: number, status: string) => {
    try {
      await apiRequest("PATCH", `/api/admin/videos/${videoId}/status`, { status });
      
      queryClient.invalidateQueries({ queryKey: ["/api/admin/videos"] });
      
      toast({
        title: "Video status updated",
        description: `Video has been ${status === "approved" ? "approved" : "rejected"}.`,
      });
    } catch (error: any) {
      toast({
        title: "Error updating video status",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  // Support ticket status handler
  const handleTicketStatus = async (ticketId: number, status: string) => {
    try {
      await apiRequest("PATCH", `/api/admin/support-tickets/${ticketId}/status`, { status });
      
      queryClient.invalidateQueries({ queryKey: ["/api/admin/support-tickets"] });
      
      toast({
        title: "Ticket status updated",
        description: `Ticket status changed to ${status.replace("_", " ")}.`,
      });
    } catch (error: any) {
      toast({
        title: "Error updating ticket status",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  // Format date
  const formatDate = (dateString: Date) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  // Video status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return <Badge className="bg-green-600">Approved</Badge>;
      case "rejected":
        return <Badge className="bg-red-600">Rejected</Badge>;
      case "pending":
        return <Badge className="bg-yellow-600">Pending</Badge>;
      default:
        return <Badge className="bg-gray-600">{status}</Badge>;
    }
  };

  // Category display
  const getCategoryName = (category: string) => {
    switch (category) {
      case "book-promotion":
        return "Book Promotion";
      case "digital-marketing":
        return "Digital Marketing";
      case "video-creation":
        return "Video Creation";
      case "payment-concept":
        return "Payment Concept";
      default:
        return category;
    }
  };

  // Ticket status badge
  const getTicketStatusBadge = (status: string) => {
    switch (status) {
      case "open":
        return <Badge className="bg-yellow-600">Open</Badge>;
      case "in_progress":
        return <Badge className="bg-blue-600">In Progress</Badge>;
      case "closed":
        return <Badge className="bg-green-600">Closed</Badge>;
      default:
        return <Badge className="bg-gray-600">{status}</Badge>;
    }
  };

  // Ticket category display
  const getTicketCategoryName = (category: string) => {
    switch (category) {
      case "payment":
        return "Payment Issues";
      case "video":
        return "Video Submission";
      case "account":
        return "Account Management";
      case "technical":
        return "Technical Support";
      default:
        return category;
    }
  };

  return (
    <div className="relative min-h-screen">
      <MatrixRain />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-rajdhani font-bold text-white">
            Admin <span className="text-matrix-green">Dashboard</span>
          </h1>
          <p className="text-gray-400">Manage videos, users, and support tickets</p>
        </motion.div>

        <Tabs
          defaultValue="videos"
          onValueChange={setActiveTab}
          className="space-y-4"
        >
          <TabsList className="bg-matrix-gray border border-matrix-green/30">
            <TabsTrigger 
              value="videos"
              className="data-[state=active]:bg-matrix-black data-[state=active]:text-matrix-green"
            >
              Videos
            </TabsTrigger>
            <TabsTrigger 
              value="support"
              className="data-[state=active]:bg-matrix-black data-[state=active]:text-matrix-green"
            >
              Support Tickets
            </TabsTrigger>
          </TabsList>

          {/* Videos Tab */}
          <TabsContent value="videos" className="space-y-4">
            <Card className="bg-matrix-gray border border-matrix-green/30 text-white">
              <CardHeader>
                <CardTitle className="text-xl font-rajdhani">Video Management</CardTitle>
              </CardHeader>
              <CardContent>
                {videosLoading ? (
                  <div className="flex justify-center py-8">
                    <span className="text-matrix-green">Loading videos...</span>
                  </div>
                ) : (
                  <>
                    {videos && videos.length > 0 ? (
                      <div className="rounded-md border border-matrix-green/30 overflow-hidden">
                        <Table>
                          <TableHeader className="bg-matrix-black/50">
                            <TableRow>
                              <TableHead className="text-gray-400">ID</TableHead>
                              <TableHead className="text-gray-400">Title</TableHead>
                              <TableHead className="text-gray-400">Category</TableHead>
                              <TableHead className="text-gray-400">Payment</TableHead>
                              <TableHead className="text-gray-400">Status</TableHead>
                              <TableHead className="text-gray-400">Submitted</TableHead>
                              <TableHead className="text-gray-400 text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {videos.map((video) => (
                              <TableRow key={video.id} className="hover:bg-matrix-black/20 border-t border-matrix-green/10">
                                <TableCell className="text-matrix-green">#{video.id}</TableCell>
                                <TableCell className="font-medium text-white">
                                  <div className="truncate max-w-[200px]">{video.title}</div>
                                </TableCell>
                                <TableCell className="text-gray-400">{getCategoryName(video.category)}</TableCell>
                                <TableCell className="text-matrix-green">${video.payment?.toFixed(2)}</TableCell>
                                <TableCell>{getStatusBadge(video.status)}</TableCell>
                                <TableCell className="text-gray-400">{formatDate(video.createdAt)}</TableCell>
                                <TableCell className="text-right">
                                  <div className="flex justify-end gap-2">
                                    {video.status === "pending" && (
                                      <>
                                        <Button 
                                          size="sm" 
                                          className="bg-green-600 hover:bg-green-700"
                                          onClick={() => handleVideoStatus(video.id, "approved")}
                                        >
                                          Approve
                                        </Button>
                                        <Button 
                                          size="sm" 
                                          variant="destructive"
                                          onClick={() => handleVideoStatus(video.id, "rejected")}
                                        >
                                          Reject
                                        </Button>
                                      </>
                                    )}
                                    {video.status !== "pending" && (
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        className="border-matrix-green/30 text-matrix-green hover:bg-matrix-black hover:text-white"
                                        onClick={() => window.open(video.link, '_blank')}
                                      >
                                        View
                                      </Button>
                                    )}
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    ) : (
                      <div className="text-center py-8 text-gray-400">
                        No videos have been submitted yet.
                      </div>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Support Tickets Tab */}
          <TabsContent value="support" className="space-y-4">
            <Card className="bg-matrix-gray border border-matrix-green/30 text-white">
              <CardHeader>
                <CardTitle className="text-xl font-rajdhani">Support Ticket Management</CardTitle>
              </CardHeader>
              <CardContent>
                {ticketsLoading ? (
                  <div className="flex justify-center py-8">
                    <span className="text-matrix-green">Loading tickets...</span>
                  </div>
                ) : (
                  <>
                    {tickets && tickets.length > 0 ? (
                      <div className="rounded-md border border-matrix-green/30 overflow-hidden">
                        <Table>
                          <TableHeader className="bg-matrix-black/50">
                            <TableRow>
                              <TableHead className="text-gray-400">ID</TableHead>
                              <TableHead className="text-gray-400">Subject</TableHead>
                              <TableHead className="text-gray-400">Category</TableHead>
                              <TableHead className="text-gray-400">Status</TableHead>
                              <TableHead className="text-gray-400">Submitted</TableHead>
                              <TableHead className="text-gray-400 text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {tickets.map((ticket) => (
                              <TableRow key={ticket.id} className="hover:bg-matrix-black/20 border-t border-matrix-green/10">
                                <TableCell className="text-matrix-green">#{ticket.id}</TableCell>
                                <TableCell className="font-medium text-white">
                                  <div className="truncate max-w-[200px]">{ticket.subject}</div>
                                </TableCell>
                                <TableCell className="text-gray-400">{getTicketCategoryName(ticket.category)}</TableCell>
                                <TableCell>{getTicketStatusBadge(ticket.status)}</TableCell>
                                <TableCell className="text-gray-400">{formatDate(ticket.createdAt)}</TableCell>
                                <TableCell className="text-right">
                                  <div className="flex justify-end gap-2">
                                    {ticket.status === "open" && (
                                      <Button 
                                        size="sm" 
                                        className="bg-blue-600 hover:bg-blue-700"
                                        onClick={() => handleTicketStatus(ticket.id, "in_progress")}
                                      >
                                        Mark In Progress
                                      </Button>
                                    )}
                                    {ticket.status === "in_progress" && (
                                      <Button 
                                        size="sm" 
                                        className="bg-green-600 hover:bg-green-700"
                                        onClick={() => handleTicketStatus(ticket.id, "closed")}
                                      >
                                        Close Ticket
                                      </Button>
                                    )}
                                    {ticket.status === "closed" && (
                                      <Button 
                                        size="sm" 
                                        variant="outline"
                                        className="border-matrix-green/30 text-matrix-green hover:bg-matrix-black hover:text-white"
                                        onClick={() => handleTicketStatus(ticket.id, "open")}
                                      >
                                        Reopen
                                      </Button>
                                    )}
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    ) : (
                      <div className="text-center py-8 text-gray-400">
                        No support tickets have been submitted yet.
                      </div>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;
